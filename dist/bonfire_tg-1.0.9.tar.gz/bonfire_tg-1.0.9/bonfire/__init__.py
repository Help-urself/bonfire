from .Bot import bot
from .methods import message
from .method import *